package kr.co.greenart.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyAspect {
	private static final Logger logger = LoggerFactory.getLogger(MyAspect.class);
	// 접근제한자 리턴타입 패키지.클래스.메소드(파라미터)
	@Pointcut("execution(* kr.co.greenart.model.file.FileDBRepository.getAllnames(..))") // Pointcut: 메소드의 경로를  변수처럼 담아둠
	public void print() {}
	
	@Pointcut("within(@org.springframework.stereotype.Repository *)") // within: @우측에 적혀있는 annotation이 붙은 모든 메소드를 실행할 때 적용됨 | 
	public void repository() {}
	
	@Around("repository()") // Before는 전, After는 후, 전후 둘 다 적용시키고 싶으면 Around
	public Object loggingTime(ProceedingJoinPoint jp) throws Throwable {
		long start = System.nanoTime();
		logger.info("시작 시간 : " + start); // 위에 적히면 실행 전
		Object proceed = jp.proceed(); // 실행되는 메소드?
		long end = System.nanoTime();
		logger.info("종료 시간 : " + end); // 밑에 적히면 실행 후
		
		logger.info(jp.getSignature().getName() + "메소드의 실행 시간 : " + (end - start));
		return proceed;
	}
	
	@Before("print()")
	public void printBefore() {
		
	}
	
	@After("print()")
	public void printAfter() {
		
	}
	
//	@Before("execution(* kr.co.greenart.model.file.FileDBRepository.getAllnames(..))") // *: 리턴타입(일반적으로는 *표로 함) | Before: 전 | execution: 실행 시 | (..): 파라미터
//	public void printBefore() {
//		logger.info("-- 파일 목록을 불러 오기 전에 실행됩니다. --");
//	}
//	@After("execution(* kr.co.greenart.model.file.FileDBRepository.getAllnames(..))") // *: 리턴타입(일반적으로는 *표로 함) | Before: 전 | execution: 실행 시 | (..): 파라미터
//	public void printAfter() {
//		logger.info("-- 파일 목록을 불러 오기 전에 실행됩니다. --");
//	}
}
